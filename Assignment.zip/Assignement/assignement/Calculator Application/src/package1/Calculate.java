package package1;

class Calculate implements iCalc
{
	//Constructor 3-Arguments
	Calculate(int first,String operator,int Second)
	{
		doCalculation(first,operator,Second);
	}
	
	//Constructor 2-Arguments
	Calculate(double first , String operator)
	{
		doCalculation(first,operator);
	}
	
	
	//doCalculation Basic-Calculator
	public void doCalculation(int a, String b,int c)
	{
		int result=0;
		switch(b)
		{
		case "*":
			result=a*c;
			getResult(result);
			break;
			
		case "-":
			result=a-c;
			getResult(result);
			break;
	
		case "+":
			result=a+c;
			getResult(result);
			break;

		case "/":
			
			int sec=checkSecondNum(c);
			if(sec !=0)
			{	
			result=a/c;
			getResult(result);
			}
			else
				System.out.println("Try Again");
			break;

		}
		
		
	}
	
	public int checkSecondNum(int c)
	{
		if(c==0)
		{
			System.out.println("Second number cannot be zero");
		}
		return c;
	}
	//doCalculation Scientific-Calculator
	
		public void doCalculation(double a, String b)
		{
			double result=0;
			switch(b)
			{
			case "sin":
				result=Math.sin(a);;
				break;
				
			case "cos":
				result = Math.cos(a);
				break;
		
			case "tangent":
				double c = Math.toRadians(a);
				result=Math.tan(c);
				break;

			case "log":
				result=Math.log(a);
				break;

			}
			
			getResult(result);
		}
		
	
	//getResult
	public void getResult(int result)
	{
		System.out.println("Result:"+result);
		System.out.println("");
	}
	
	public void getResult(double result)
	{
		System.out.println("Result:"+result);
		System.out.println("");
	}
}