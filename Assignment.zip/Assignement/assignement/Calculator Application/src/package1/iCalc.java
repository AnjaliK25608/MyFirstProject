package package1;

public interface iCalc {
	
	void doCalculation(int a, String b,int c);
	void doCalculation(double e, String d);
	void getResult(int result);
	void getResult(double result);

}
