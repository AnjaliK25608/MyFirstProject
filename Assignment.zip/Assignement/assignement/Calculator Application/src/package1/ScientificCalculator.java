package package1;

import java.util.Scanner;

public class ScientificCalculator {
	
	ScientificCalculator()
	{
		
		
		
		char ch='a';
		
		do
		{
		
			Scanner sc= new Scanner(System.in);
			    //ch="";
				System.out.println("Degree");
				double firstNum=sc.nextDouble();
				
				System.out.println("Enter Operation");
				String operator =sc.next();
					
				Calculate c=new Calculate(firstNum,operator);
				System.out.println("Press any key to continue");
				System.out.println("You can exit by pressing n");
				ch=sc.next().charAt(0);
				
			}while(ch != 'n');
	}
	
}
