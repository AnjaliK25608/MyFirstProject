package package1;

import java.util.Scanner;

public class Calculator {
	
	Calculator()
	{
		char ch='x';
		do
		{
		
				Scanner sc= new Scanner(System.in);
				
				System.out.println("Enter First Number");
				int firstNum=sc.nextInt();
				
				System.out.println("Enter Operation");
				String operator =sc.next();
				
				System.out.println("Enter Second Number");
				int SecondNum=sc.nextInt();
				
				
				Calculate c=new Calculate(firstNum,operator,SecondNum);
				System.out.println("Press any key to continue");
				System.out.println("You can exit by pressing n");
				ch=sc.next().charAt(0);
		
		}while(ch != 'n');
	}

}
