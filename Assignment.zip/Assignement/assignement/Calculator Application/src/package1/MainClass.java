package package1;

import java.util.Scanner;

public class MainClass {

	public static void main(String[] args) {
		
		UseCalculator uc= new UseCalculator();

	}
	
}

class UseCalculator
{
	UseCalculator()
	{
		Scanner sc=new Scanner(System.in);
		char choice='x';
		do {
		
				System.out.println("Please make your choice\n");
				System.out.println("Press a for Basic-Calculator");
				System.out.println("Press b for Scientific-Calculator");
				System.out.println("Press n to Exit");
				
				choice=sc.next().charAt(0);
				
				switch(choice)
				{
				case 'a':
					Calculator c= new Calculator();
					break;
					
				case 'b':
					
					ScientificCalculator s=new ScientificCalculator();
					break;
				
				case 'n':
					System.exit(0);
					break;
					
				default:
					System.out.println("Invalid Choice");
					
				}
		
			}while(choice != 'n');
		
	}
}